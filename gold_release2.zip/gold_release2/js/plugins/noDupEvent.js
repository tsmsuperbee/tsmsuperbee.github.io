for (const event of $gameMap._events) {
  if (event) {
    event._starting=false
  }
}